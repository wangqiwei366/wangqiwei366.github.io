# KIMI Blog · HarmonyOS NEXT

这是 KIMI Blog 的鸿蒙 NEXT 原生阅读版，使用 ArkTS Stage 模型和 ArkUI 构建，不使用网页容器。

功能包括文章列表、搜索、标签和年份筛选、文章阅读、收藏、自我介绍、离线缓存，以及启动/恢复后的自动同步。文章和自我介绍从公开网站读取，管理端发布到 GitHub Pages 后，应用会在下次启动或恢复时拉取最新内容。

## 在 DevEco Studio 中构建

当前 Windows 工作区没有安装 DevEco Studio、HarmonyOS SDK、hvigor 或 hdc，因此这里无法生成签名后的 `.hap`。在安装 DevEco Studio（API 12 或更新版本）的电脑上打开本目录，等待依赖同步，然后选择 `entry` 模块运行或构建 HAP。

首次构建需要在 DevEco Studio 中配置本地签名。工程使用包名 `com.kimi.blog.harmony`，版本 `1.1.1`。

目录中的 `entry/src/main/resources/base/media` 已包含首页背景和头像，文章离线种子位于 `entry/src/main/resources/rawfile/snapshot.json`。在网站文章更新后，从 `native-apps/tools` 运行 `Sync-Harmony-Seed.ps1`，脚本会重新抓取公开文章和自我介绍，并把最新快照复制到鸿蒙工程。

网络同步需要 `ohos.permission.INTERNET`，已在 `entry/src/main/module.json5` 声明。应用会优先显示本地快照，联网成功后更新文章正文和自我介绍；失败时继续使用上次缓存。
