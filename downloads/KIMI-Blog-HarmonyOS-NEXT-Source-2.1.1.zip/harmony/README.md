> 2.1.1 更新（2026-11-02）：请优先查看 ../RELEASE-2.1.1.md 的版本、构建和签名说明。下面保留原有工程说明。

# KIMI Blog · HarmonyOS NEXT

这是 KIMI Blog 的鸿蒙 NEXT 原生阅读版，使用 ArkTS Stage 模型和 ArkUI 构建，不使用网页容器。

2.1.1 包含文章列表、搜索、标签和年份筛选、阅读、收藏、关于页、离线缓存、底部导航，以及与网站通用的评论注册、登录、发布和自动刷新。文章与评论共用网站服务；收藏和阅读设置保存在本机。

## 在 DevEco Studio 中构建

在配置了对应 HarmonyOS SDK 的 DevEco Studio 中打开本目录，完成依赖同步和设备签名后，选择 `entry` 模块运行或构建 HAP。该 NEXT 工程尚未经过 NEXT 真机安装验证或生产分发签名。

首次构建需要在 DevEco Studio 中配置本地签名。工程使用包名 `com.kimi.blog.harmony`，版本 `2.1.1`（versionCode 21001）。源码包不包含证书、私钥或用户会话。

## OpenHarmony API 12 开发包

同一 ArkTS 源码已通过完整 OpenHarmony API 12 SDK 和官方 Hvigor 5.2.2 编译，生成真实 Stage 模型的未签名 HAP（含 `ets/modules.abc`）。它是 OpenHarmony 开发验证包，不能视为已完成 HarmonyOS NEXT 正式分发验证的安装包。使用 `Build-OpenHarmony.ps1` 并传入 SDK、Hvigor CLI、Java 和 Node 路径可重现此构建；脚本只修改临时目录内的 SDK/设备配置。

目录中的 `entry/src/main/resources/base/media` 已包含首页背景和头像，文章离线种子位于 `entry/src/main/resources/rawfile/snapshot.json`。在网站文章更新后，运行 `native-apps/tools/sync_snapshot.py` 可抓取完整文章目录及正文，并把快照同步到各端工程。

网络同步需要 `ohos.permission.INTERNET`，已在 `entry/src/main/module.json5` 声明。应用会优先显示本地快照，联网成功后更新文章正文和自我介绍；失败时继续使用上次缓存。
