﻿param(
    [Parameter(Mandatory=$true)][string]$SdkRoot,
    [Parameter(Mandatory=$true)][string]$HvigorCli,
    [Parameter(Mandatory=$true)][string]$JavaHome,
    [string]$Node = 'node',
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '../dist')
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path (Join-Path $SdkRoot '12/ets/oh-uni-package.json'))) { throw 'SdkRoot must contain the complete OpenHarmony API 12 SDK under 12/.' }
if (-not (Test-Path -LiteralPath $HvigorCli)) { throw 'Hvigor CLI not found.' }
$stage = Join-Path ([IO.Path]::GetTempPath()) ('KimiBlogOpenHarmony-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
foreach ($name in @('AppScope','entry','hvigor','hvigorfile.ts','oh-package.json5')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $stage -Recurse
}
$profile = @{
    app = @{ products = @(@{ name='default'; compileSdkVersion=12; compatibleSdkVersion=12; targetSdkVersion=12; runtimeOS='OpenHarmony' }); buildModeSet=@(@{name='debug'},@{name='release'}) }
    modules = @(@{name='entry'; srcPath='./entry'; targets=@(@{name='default';applyToProducts=@('default')})})
}
[IO.File]::WriteAllText((Join-Path $stage 'build-profile.json5'),($profile | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
$modulePath=Join-Path $stage 'entry/src/main/module.json5'
$module=Get-Content -Raw -LiteralPath $modulePath | ConvertFrom-Json
$module.module.deviceTypes=@('default')
[IO.File]::WriteAllText($modulePath,($module | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $stage 'local.properties'),('sdk.dir='+$SdkRoot.Replace('\','/')),[Text.UTF8Encoding]::new($false))
$modules=$HvigorCli
1..4 | ForEach-Object { $modules=Split-Path $modules -Parent }
$env:NODE_PATH=$modules
$env:JAVA_HOME=$JavaHome
$env:PATH=(Join-Path $JavaHome 'bin')+';'+$env:PATH
# Hvigor compares native real paths; packaged Windows shells can virtualize AppData.
$physical=& $Node -e "console.log(require('fs').realpathSync.native(process.argv[1]))" $stage
if ($LASTEXITCODE -ne 0 -or -not $physical) { throw 'Unable to resolve the build directory.' }
Push-Location -LiteralPath $physical
try {
    & $Node $HvigorCli --mode module -p product=default -p module=entry@default assembleHap --no-daemon
    if ($LASTEXITCODE -ne 0) { throw 'OpenHarmony build failed.' }
    New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
    $hap=Get-ChildItem -LiteralPath (Join-Path $physical 'entry/build/default/outputs/default') -Filter '*unsigned.hap' | Select-Object -First 1
    if (-not $hap) { throw 'Unsigned HAP not produced.' }
    Copy-Item -LiteralPath $hap.FullName -Destination (Join-Path $OutputDirectory 'KIMI-Blog-OpenHarmony-API12-2.2.1-unsigned.hap')
    Write-Output 'Built OpenHarmony API 12 Stage HAP. Device signing and runtime validation remain required.'
} finally { Pop-Location }
